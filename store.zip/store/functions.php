<?php

function postParams($value, $array)
{
    return array_key_exists($value, $array) ? $array[$value] : null;
}