<?php

header('Location: /store/pages');